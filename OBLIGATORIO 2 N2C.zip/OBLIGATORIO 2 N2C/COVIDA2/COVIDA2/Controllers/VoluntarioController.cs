﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace COVIDA2.Controllers
{
    public class VoluntarioController : Controller
    {
        Sistema sistema = Sistema.Instancia;
        // GET: Producto
        public ActionResult Index(string mensaje)
        {
            if (Session["rol"] == null)
            {
                return RedirectToAction("/usuario/login");
            }
            ViewBag.voluntario = sistema.Usuarios;
            ViewBag.mensaje = mensaje;
            return View();
        }

        [HttpGet]
        public ActionResult AltaVol()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            if (Session["rol"].ToString() != "admin")
            {
                return Redirect("Index");

            }

            return View(new Voluntario());
        }
        [HttpPost]
        public ActionResult AltaVol(Voluntario unVol)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            if (Session["rol"].ToString() != "admin")
            {
                return Redirect("Index");
            }


            string msg = "";

            if (sistema.nuevoVoluntario(unVol) == "ok" && unVol.Nombre.Length>3 && unVol.Telefono> 8/* && unVol.Ci>8*/)
            {
                msg = "El voluntario fue dado de alta exitosamente";
                return RedirectToAction("Index", new { mensaje = msg });

            }
            else
            {
                msg = sistema.nuevoVoluntario(unVol);
            }
            
            ViewBag.mensaje = msg;

            return View(unVol);
        }

        [HttpGet]
        public ActionResult ModificarVoluntario(int id)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            if (Session["rol"].ToString() != "admin")
            {
                return Redirect("Index");
            }
            Voluntario voluntario = sistema.getVoluntarioById(id);
            return View(voluntario);

        }


        [HttpPost]
        public ActionResult ModificarVoluntario(int ci, Voluntario unV)
        {
            string msg = "";
            if (sistema.ModificarVoluntario(ci, unV) == "ok" && unV.Nombre.Length>3 && (unV.Rol=="admin" || unV.Rol =="usuario"))
            {
                msg = "Modificacion exitosa";

            }
            else
            {
                msg = sistema.ModificarVoluntario(ci, unV);

            }
            ViewBag.mensaje = msg;
            
            return View(unV);
        }

    }
}