﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace COVIDA2.Controllers
{
    public class DonacionProdController : Controller
    {
        Sistema sistema = Sistema.Instancia;
        // GET: Donacion Producto
        public ActionResult Index(string mensaje)
        {
            ViewBag.mensaje = mensaje;
            return View();



        }

        [HttpGet]
        public ActionResult AltaDonProd()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }

            return View(new ProductoDonado());
        }
        [HttpPost]

        public ActionResult AltaDonProd(ProductoDonado unaDon, int ProductoDon)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }

            Producto unP = sistema.getProductoById(ProductoDon);
            string msg = "";
            unaDon.Producto = unP;

            if (sistema.nuevoProductoPorDonar(unaDon.Producto, unaDon.Cantidad) == "ok" && unaDon.Cantidad > 0)
            {
                msg = "La donacion fue dado de alta exitosamente";
                return RedirectToAction("AltaDonProd", new { mensaje = msg });

            }
            else
            {
                msg = ProductoDonado.validar(unaDon.Producto, unaDon.Cantidad);
            }
            ViewBag.mensaje = msg;

            return View(unaDon);
        }

        public ActionResult FinalizarAlta()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            string nombre = (string)(Session["nombre"]);
            Voluntario unV = sistema.getUsuarioByNombre(nombre);
            string msg;
            if (unV != null && sistema.nuevaDonacionProducto(unV) == "ok")
            {
                msg = "Alta exitosa";
                return RedirectToAction("Index", new { mensaje = msg });
            }
            else
            {
                msg = sistema.nuevaDonacionProducto(unV);
            }

            ViewBag.mensaje = msg;
            return View();
        }



        [HttpGet]
        public ActionResult AltaDonEco()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }

            return View(new DonacionEconomica());
        }
        [HttpPost]
        public ActionResult AltaDonEco(DonacionEconomica unaDon)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }

            string nombre = (string)(Session["nombre"]);
            Voluntario unV = sistema.getUsuarioByNombre(nombre);
            string msg = "";
            if (unaDon != null && unaDon.Valor > 0 && sistema.nuevaDonacionEconomica(unaDon, unV) == "ok")
            {
                msg = "Alta exitosa";
                return RedirectToAction("Index", new { mensaje = msg });
            }
            else
            {
                msg = "#Error: Intente nuevamente";


            }

            ViewBag.mensaje = msg;
            return View(unaDon);
        }
        [HttpGet]
        public ActionResult DonacionPorFecha()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            ViewBag.Lista = new List<Donacion>();
            return View();
           
        }
        [HttpPost]

         public ActionResult DonacionPorFecha(DateTime desde, DateTime hasta)
         {
            
             string nombre = (string)(Session["nombre"]);
             Voluntario unV = sistema.getUsuarioByNombre(nombre);
             if(unV != null && desde != null && hasta != null)
             {
                ViewBag.Lista = sistema.donacionesPorVoluntarioFecha(unV, desde, hasta);
             }
             
            
             return View();
         }
        public ActionResult UltimasDon()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            ViewBag.Lista = new List<Donacion>();
            ViewBag.Lista = sistema.donadosDistintos();
            return View();

        }

        public ActionResult MasDonado()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            ViewBag.Lista = new ProductoDonado();
            ViewBag.Lista = sistema.masDonado();
			
            return View();
        }
       

    }
}