﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace COVIDA2.Controllers
{
    public class UsuarioController : Controller
    {
        // GET: Usuario

        Sistema sistema = Sistema.Instancia;
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string nombre, string password)
        {
            Voluntario usuario = sistema.getUsuarioByNombre(nombre);

            if (usuario == null)
            {
                ViewBag.mensaje = "Usuario o contraseña incorrectos";
                return View();
            }

            Session["rol"] = usuario.Rol;
            Session["nombre"] = usuario.Nombre;
            return Redirect("/Producto/Index");
        }

        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("login");
        }
    }


}