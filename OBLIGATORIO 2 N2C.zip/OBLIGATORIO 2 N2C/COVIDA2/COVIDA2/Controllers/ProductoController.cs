﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Dominio;

namespace COVIDA2.Controllers
{
    public class ProductoController : Controller
    {
        Sistema sistema = Sistema.Instancia;
        // GET: Producto
        public ActionResult Index(string mensaje)
        {

            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            ViewBag.productos = sistema.Productos;
            ViewBag.mensaje = mensaje;
            return View();
        }

        [HttpGet]
        public ActionResult AltaProd()
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            if (Session["rol"].ToString() != "admin")
            {
                return Redirect("Index");
            }
            return View(new Producto());
        }

     
        
        [HttpPost]
        public ActionResult AltaProd(Producto unProd)
        {
            string msg = sistema.nuevoProducto(unProd);

            if (msg == "ok" && unProd.Nombre.Length>3 && unProd.Peso>0 && unProd.Precio > 0)
            {
                msg = "El producto fue dado de alta exitosamente";
                return RedirectToAction("Index", new { mensaje = msg });
            }

            ViewBag.mensaje = msg;

            return View(unProd);
        }
        [HttpGet]

        public ActionResult ModificarProducto(int id)
        {
            if (Session["rol"] == null)
            {
                return Redirect("/usuario/login");
            }
            if (Session["rol"].ToString() != "admin")
            {
                return Redirect("Index");
            }
            Producto producto = sistema.getProductoById(id);

            return View(producto);
        }



        [HttpPost]
        public ActionResult ModificarProducto(int id, Producto producto)
        {
            string msg = "";
            if(sistema.ModificarProducto(id, producto) == "ok" && producto.Peso>0 && producto.Precio>0)
            {
                msg = "Modificacion exitosa";
                RedirectToAction("Index", new { mensaje = msg });
            }
            else
            {
                msg = sistema.ModificarProducto(id, producto);

            }
            ViewBag.mensaje = msg;

            return View(producto);
        }
    }
}