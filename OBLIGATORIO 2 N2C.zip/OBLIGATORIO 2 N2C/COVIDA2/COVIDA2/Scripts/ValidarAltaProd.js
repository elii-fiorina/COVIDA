﻿$("#formAltaProd").submit(function () {
	let validacion = true;
    if ($("#nombreProd").val().length <= 2) {

		alert(`#ERROR: Nombre debe tener al menos 3 caracter`);
		validacion = false;
    }
     if ($("#pesoProd").val() < 0) {
		 alert(`#ERROR: Peso debe ser mayor a 0`);
		 validacion = false;

     }
     if ($("#precioProd").val() < 0) {

		 alert(`#ERROR: Precio debe ser mayor a 0`);
		 validacion = false;

     }
	return validacion;
})
