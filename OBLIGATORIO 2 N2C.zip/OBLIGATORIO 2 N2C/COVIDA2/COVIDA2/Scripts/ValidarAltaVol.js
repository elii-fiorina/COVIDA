﻿$("#formVoluntario").submit(function () {
    if ($("#nombreVol").val().length < 3) {

        alert(`#ERROR: Nombre debe tener al menos 3 caracteres`);
    }
    if ($("#ciVol").val() < 8) {
        alert(`#ERROR: CI tiene que tener al menos 8 caracteres`);
    }
    if ($("#telefonoVol").val() < 8) {

        alert(`#ERROR: Telefono debe tener al menos 8 caracteres`);
    }
    return false;
})