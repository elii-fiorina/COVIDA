﻿$("#FinalizarAlta").click(function () {
    return @Url.Action("FinalizarAlta", "DonacionProd");
});