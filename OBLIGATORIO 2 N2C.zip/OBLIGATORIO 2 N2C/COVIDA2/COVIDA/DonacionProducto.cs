﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
	public class DonacionProducto : Donacion
    {
        
		#region Atributos
		private List<ProductoDonado> productos;
		#endregion

		#region Propiedades

		public List<ProductoDonado> Productos{
			set { productos = value; }
			get { return productos; }
		}
        
        #endregion


        #region Metodos
        public DonacionProducto()
        {

        }
		public DonacionProducto(List<ProductoDonado> productos, DateTime fecha, Voluntario voluntario) : base()
		{
			this.productos = productos;
			base.Fecha = fecha;
            this.voluntario = voluntario;
            foreach (ProductoDonado prod in productos)
			{
				Valor += prod.Producto.Precio;
			}
			tipoDon = TipoDon.producto;
			calcularVale();

		}
		public DonacionProducto(List<ProductoDonado> productos) : base()
        {
			base.Fecha = DateTime.Now;
			this.productos = productos;
			tipoDon = TipoDon.producto;
			foreach (ProductoDonado prod in productos)
			{
				Valor += prod.Producto.Precio * prod.Cantidad;
			}
			calcularVale();
		}

        public override string ToString()
        {
            string str = "DONACION PRODUCTO | ID: " + id + " | Fecha: " + fecha.ToShortDateString() +  "\n";
            foreach (ProductoDonado pd in productos)
            {
                str += pd.Producto.Nombre + ": " + pd.Cantidad + " | ";
            }

            return str;
        }

        public static string validar(List<ProductoDonado> productos)
			{
			string validacion = "#Error/es: ";
			int i = 0;
			while (i < productos.Count && validacion == "#Error/es: ")
			{
				Producto prod = productos[i].Producto;
				int cant = productos[i].Cantidad;

				if (ProductoDonado.validar(prod, cant) != "ok")
				{
					validacion += "Producto: " + prod.Nombre + "invalido: ";
					validacion += ProductoDonado.validar(prod, cant);
				}

				i++;
			}
			if (validacion == "#Error/es: ")
			{
				validacion = "ok";
			}
			return validacion;
		}

		public override void calcularVale()
		{
			double descuento = 0;
			if (valor >= 1000)
			{
				descuento = 0.1;
			}
			else if (valor >= 2000)
			{
				descuento = 0.12;
			}
			vale = valor * descuento;
		}
		#endregion
	}
}
