﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
	public class DonacionEconomica: Donacion
    {
        #region Atributos		
         
		#endregion

		#region Propiedades
 
      

        #endregion


        #region Metodos
        public DonacionEconomica()
		{
			this.Fecha = DateTime.Now;
			valor = 0;
			tipoDon = TipoDon.economica;
		}
		public DonacionEconomica(float monto)
		{
			this.Fecha = DateTime.Now;
			this.valor = monto;
			tipoDon = TipoDon.economica;
			calcularVale();

		}
		public DonacionEconomica(float monto, DateTime fecha, Voluntario voluntario)
		{
			this.fecha = fecha;
			this.valor = monto;
            this.voluntario = voluntario;
			tipoDon = TipoDon.economica;
			calcularVale();

		}

		public override void calcularVale()
        {            
            if (valor <= 1000)
            {
                vale = valor * 0.05;
            }
			else if(valor > 1000 && valor <= 2000){
				vale = valor * 0.08;
			}
			else{
				vale = valor * 0.1;
			}
		}

		public static bool validar(DonacionEconomica don)
		{
			bool esValida = false;
			if (don.valor > 0)
			{
				esValida = true;
			}
			return esValida;
		}

		public override string ToString()
		{
			return "DONACION ECONOMICA | ID: "+ this.id + " | Fecha: " + this.fecha.ToShortDateString() + " | Monto: " + this.valor;
		}

		#endregion
	}
}
