﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
	public class Sistema
	{
		private List<Producto> productos;
		private List<Donacion> donaciones;
        private List<ProductoDonado> productosPorDonar;
		private List<Centro> centros;
		private List<Voluntario> usuarios;
		private static Sistema instancia;

		public static Sistema Instancia
		{
			get
			{
				if (instancia == null)
				{
					instancia = new Sistema();
				}
				return instancia;
			}
		}

		public List<Producto> Productos
		{
			get { return productos; }
		}
		public List<Donacion> Donaciones
		{
			set { donaciones = value; }
			get { return donaciones; }
		}
        public List<ProductoDonado> ProductosPorDonar
        {
            set { productosPorDonar = value; }
            get { return productosPorDonar; }
        }
        public List<Centro> Centros
		{
			set { centros = value; }
			get { return centros; }
		}
		public List<Voluntario> Usuarios
		{
			set { usuarios = value; }
			get { return usuarios; }
		}

		public Sistema(){

			productos = new List<Producto>();
			centros = new List<Centro>();
			donaciones = new List<Donacion>();
            usuarios = new List<Voluntario>();
			productosPorDonar = new List<ProductoDonado>();
			precarga();
		}

		// Precarga de datos. Se llama al instanciar Sistema.
		public void precarga(){
			cargaProductos();
			cargaCentros();
			precargaUsuarios();
            cargaDonaciones(); 
		}

		// Recibe un producto, lo valida y si es valido, lo añade a la Lista.

		public string nuevoProducto(Producto nProd){
			string alta = "#Error/es: ";
			if (getProductoById(nProd.Id) != null)
			{
				alta += "El producto ya existe.";
			}
			else 
			{
				alta = Producto.validar(nProd.Nombre, nProd.Precio, nProd.Peso);
				if (!Producto.ValidarTipo(nProd.Tipo))
				{
					alta = "Tipo invalido.";
				}
			}
            if (alta == "ok")
			{
				nProd.Id = GestorId.GenProdId;
                productos.Add(nProd);
            }
            return alta;
		}
        public string ModificarProducto(int id, Producto producto)
        {
            string msg = "#Error: Intente nuevamente";
            Producto productoModificar = getProductoById(id);
            if (productoModificar != null && Producto.validar(productoModificar.Nombre, producto.Precio, producto.Peso) == "ok")

            {
                if (productoModificar.Precio > 0)
                {
                    productoModificar.Precio = producto.Precio;

                    if (productoModificar.Peso > 0)
                    {
                        productoModificar.Peso = producto.Peso;
                        msg = "ok";
                    }
                }
                else
                {
                    msg = Producto.validar(productoModificar.Nombre, producto.Precio, producto.Peso);
                }
            }return msg;
        }
        public string ModificarVoluntario(int id, Voluntario voluntario)
        {
            string msg = "";
            Voluntario voluntarioModificar = getVoluntarioById(id);
            if (voluntarioModificar != null && voluntarioModificar.Rol == "usuario" || voluntarioModificar.Rol == "admin" && voluntarioModificar.Nombre.Length > 0)
            {
             
                 voluntarioModificar.Rol = voluntario.Rol;
  
                 voluntarioModificar.Nombre = voluntario.Nombre;
                 msg = "ok";

            }
            else
            {
                msg = "#Error: Datos incorrectos, intente nuevamente";
            }

            return msg;
        }

        // Recibe un centro, lo valida y si es valido, lo añade a la Lista.
        public string nuevoCentro(Centro nCen)

		{
			string msg = "";
			bool valido = Centro.validar(nCen) == "ok";

			if (valido)
			{
				nCen.Id = GestorId.GenCenId;
				centros.Add(nCen);
				msg += "ok";
			}
			else
			{
				msg += "# ERROR:" + nCen.Nombre + " Centro ya existente.";
			}
			return msg;
		}

		// Recibe un voluntario, lo valida y si es valido, lo añade a la Lista.
		public string nuevoVoluntario(Voluntario nVol)
		{
			string alta = Voluntario.validar(nVol);
			bool existeCi = getVoluntarioById(nVol.Ci) != null;
			bool existeNombre = getUsuarioByNombre(nVol.Nombre) != null;
			if (existeCi)
			{
				alta = "# ERROR: " + nVol.Ci + " - Voluntario ya existente.";
			}
			if (existeNombre)
			{
				alta = "# ERROR: nombre ya registrado.";
			}

			if (alta == "ok")
			{
				nVol.Rol = "usuario";
				usuarios.Add(nVol);
            }

			return alta;
		}
     
        // Recibe una donacion, la valida y si es valido, lo añade a la Lista.
        public string nuevaDonacionEconomica(DonacionEconomica nDonacion, Voluntario vol){
			string msg = "";
            

			if (DonacionEconomica.validar(nDonacion))
			{
				nDonacion.Id = GestorId.GenDonId;
				nDonacion.Voluntario = vol;
				donaciones.Add(nDonacion);
				msg += "ok";
			}
			else
			{
				msg += "# ERROR: Donacion ya existente.";
			}
          

			return msg;
		}

        public string nuevoProductoPorDonar(Producto producto, int cantidad)
        {
            string alta = "# Error: La cantidad debe ser de al menos 1.";
            if(cantidad>0)
            {
                ProductoDonado don = new ProductoDonado(producto, cantidad);
                productosPorDonar.Add(don);
                alta = "ok";
            }
            
            return alta;
        }
		
		public string nuevaDonacionProducto(Voluntario voluntario)

		{
			string alta = "# Error:";
			    if(productosPorDonar.Count > 0)
			{
				if (getVoluntarioById(voluntario.Ci) != null)
				{
					DonacionProducto nDon = new DonacionProducto(productosPorDonar);
					nDon.Id = GestorId.GenDonId;
					donaciones.Add(nDon);
					productosPorDonar = new List<ProductoDonado>();

					alta = "ok";
				}
				else
				{
					alta += "Voluntario invalidos.";

				}
			}
			else
			{
				alta += " No hay productos por donar.";
			}
			
			return alta;
		}
		// Sobrecarga para la PRECARGA.
		public string nuevaDonacionProducto(List<ProductoDonado> lista, Voluntario voluntario, DateTime fecha)
		{
			string alta = "# Error:";
			if (lista.Count > 0)
			{
				if (getVoluntarioById(voluntario.Ci) != null && DonacionProducto.validar(lista) == "ok")
				{
					DonacionProducto nDon = new DonacionProducto(lista, fecha, voluntario);
					nDon.Id = GestorId.GenDonId;
					donaciones.Add(nDon);
					alta = "ok";
				}
				else
				{
					alta += " Voluntario invalidos o lista de productos invalida.";
				}
			}
			else
			{
				alta += " No hay productos por donar.";
			}

			return alta;
		}



		// Recibe un tipo de porudcto y retorna una lista con los productos de dicho tipo.
		public List<Producto> getProdsByType(Producto.TipoProd tipo)
		{
			List<Producto> productos = new List<Producto>();

			foreach (var item in productos)
			{
				if (item.Tipo == tipo){
					productos.Add(item);
				}
			}

			return productos;
		}

		// Recibe un id por string, lo parsea y retorna el Centro que tenga ese Id, si no lo encuentra retorna null.
		public Centro getCentroById(int id){
			bool encontrado = false;
			Centro centro = null;
			int i = 0;
			while (!encontrado && i < centros.Count)
			{
				if (centros[i].Id == id)
				{
					centro = centros[i];
					encontrado = true;
				}
				i++;
			}
			return centro;
		}

		// Recibe un id por string, lo parsea y retorna el Producto que tenga ese Id, si no lo encuentra retorna null.
		public Producto getProductoById(int id)
		{
			bool encontrado = false;
			Producto producto = null;
			int i = 0;
			while (!encontrado && i < productos.Count)
			{
				if (productos[i].Id == id)
				{
					producto = productos[i];
					encontrado = true;
				}
				i++;
			}
			return producto;
		}

        public Voluntario getUsuarioByNombre(string nombre)
        {
            bool encontrado = false;
			Voluntario usuario = null;
            int i = 0;
            while (!encontrado && i < usuarios.Count)
            {
                if (usuarios[i].Nombre == nombre)
                {
                    usuario = usuarios[i];
                    encontrado = true;
                }
                i++;
            }
            return usuario;
        
    }

		// Recibe un nombre y retorna el Producto que tenga ese Nombre, si no lo encuentra retorna null.
		public Producto getProductoByNombre(string nombre)
		{
			bool encontrado = false;
			Producto producto = null;
			int i = 0;
			while (!encontrado && i < productos.Count)
			{
				if (productos[i].Nombre == nombre)
				{
					producto = productos[i];
					encontrado = true;
				}
				i++;
			}
			return producto;
		}

		// Recibe el id de un centro y retorna un string con la lista de voluntarios en ese centro.
		public string getStrVoluntariosCentro(int cId){
			
			Centro centro = getCentroById(cId);
			string strVoluntarios = "### CENTRO INEXISTENTE ###";

			if (centro != null)
			{
				strVoluntarios = centro.getStrVoluntarios();
			}

			return strVoluntarios;
		}

		// Recibe un id y retorna el Voluntario que tenga ese Id, si no lo encuentra retorna null.
		public Voluntario getVoluntarioById(int id){
			bool encontrado = false;
			Voluntario voluntario = null;
			int i = 0;
			while (!encontrado && i < usuarios.Count)
			{
					if (usuarios[i].Ci == id)
					{
						encontrado = true;
                    voluntario = usuarios[i];
					}
                i++;
            }
				
            return voluntario;
        }
			
		
        private void precargaUsuarios()
		{
			usuarios.Add(Voluntario.nuevoAdmin("Eli", "1"));
			usuarios.Add(Voluntario.nuevoAdmin("Rafa", "1"));
			usuarios.Add(Voluntario.nuevoAdmin("admin", "admin"));
			cargaVoluntarios();
		}
		private void cargaVoluntarios()
		{
			Voluntario v1 = new Voluntario("usuario", 12345678, 091234567, new DateTime(1978, 12, 20), "usuario");
			Voluntario v2 = new Voluntario("Alberto", 98798798, 099876543, new DateTime(1990, 1, 2), "pass");
			Voluntario v3 = new Voluntario("Rafael", 50003983, 091665267, new DateTime(1999, 6, 28), "pass");
			Voluntario v4 = new Voluntario("Ignacio", 69123321, 46758181, new DateTime(1914, 6, 28), "pass");
			Voluntario v5 = new Voluntario("Pedro", 45645645, 11112222, new DateTime(1982, 9, 30), "pass");
			Voluntario v6 = new Voluntario("Alison", 78978978, 33334444, new DateTime(1995, 12, 20), "pass");
			Voluntario v7 = new Voluntario("Valeria", 32132132, 55556666, new DateTime(1991, 3, 2), "pass");
			Voluntario v8 = new Voluntario("Denna", 65465465, 77778888, new DateTime(1988, 9, 21), "pass");
			Voluntario v9 = new Voluntario("Gabriela", 75375375, 99991111, new DateTime(1984, 5, 28), "pass");
			Voluntario v10 = new Voluntario("Karen", 95195195, 15915915, new DateTime(1976, 12, 28), "pass");
			// v11 falla por tener la misma Ci que v10.
			Voluntario v11 = new Voluntario("VOLUNTARIO ERROR", 95195195, 15915915, new DateTime(1976, 12, 28), "pass");
			// v12 falla por tener el mismo nombre que v10.
			Voluntario v12 = new Voluntario("Karen", 45675312, 15915915, new DateTime(1976, 12, 28), "pass1");


			if (nuevoVoluntario(v1) == "ok")
			{
				centros[0].sumarVoluntario(v1);
			}
			if (nuevoVoluntario(v2) == "ok")
			{
				centros[1].sumarVoluntario(v2);
			}
			if (nuevoVoluntario(v3) == "ok")
			{
				centros[2].sumarVoluntario(v3);
			}
			if (nuevoVoluntario(v4) == "ok")
			{
				centros[3].sumarVoluntario(v4);
			}
			if (nuevoVoluntario(v5) == "ok")
			{
				centros[4].sumarVoluntario(v5);
			}
			if (nuevoVoluntario(v6) == "ok")
			{
				centros[0].sumarVoluntario(v6);
			}
			if (nuevoVoluntario(v7) == "ok")
			{
				centros[0].sumarVoluntario(v7);
				centros[1].sumarVoluntario(v7);
			}
			if (nuevoVoluntario(v8) == "ok")
			{
				centros[2].sumarVoluntario(v8);
			}
			if (nuevoVoluntario(v9) == "ok")
			{
				centros[3].sumarVoluntario(v9);
			}
			if (nuevoVoluntario(v10) == "ok")
			{
				centros[4].sumarVoluntario(v10);
			}
			if (nuevoVoluntario(v11) == "ok")
			{
				centros[4].sumarVoluntario(v11);

			}
		}

		private void cargaProductos(){ 
			nuevoProducto(new Producto("Papa", 1, 35, Producto.TipoProd.alimentoFresco));
			nuevoProducto(new Producto("Cebolla", 1, 45, Producto.TipoProd.alimentoFresco));
			nuevoProducto(new Producto("Kiwi", 1, 235, Producto.TipoProd.alimentoFresco));
			nuevoProducto(new Producto("Hipoclorito", 1, 1100, Producto.TipoProd.productoLimpieza));
			nuevoProducto(new Producto("Desinfectante", 1, 130, Producto.TipoProd.productoLimpieza));
			nuevoProducto(new Producto("Alcohol en gel", 1, 250, Producto.TipoProd.productoHigiene));
			nuevoProducto(new Producto("Jabon", 1, 60, Producto.TipoProd.productoHigiene));
			nuevoProducto(new Producto("Leche", 1, 29, Producto.TipoProd.bebida));
			nuevoProducto(new Producto("Leche en polvo", 1, 110, Producto.TipoProd.alimentoNoPerecedero));
			nuevoProducto(new Producto("Lata choclo", 1, 30, Producto.TipoProd.alimentoNoPerecedero));
			nuevoProducto(new Producto("Lata arvejas", 1, 30, Producto.TipoProd.alimentoNoPerecedero));
			nuevoProducto(new Producto("Lata arvejas", 1, 30, Producto.TipoProd.alimentoNoPerecedero));
			nuevoProducto(new Producto("Coquita en botella de vidrio :)", 1, 110, Producto.TipoProd.bebida));
			// PROD ERROR #1 y #2 fallan por tener valores invalidos en precio y peso respectivamente.
			nuevoProducto(new Producto("PROD ERROR #1", 11, 0, Producto.TipoProd.productoHigiene));
			nuevoProducto(new Producto("PROD ERROR #2", 0, 11, Producto.TipoProd.productoHigiene));
			// E3 falla por tener un nombre menor a 3 caracteres.
			nuevoProducto(new Producto("E3", 1, 11, Producto.TipoProd.productoHigiene));

		}
		private void cargaCentros(){
			nuevoCentro(new Centro("Shopping", "Calle 13"));
			nuevoCentro(new Centro("Hope", "18 de Julio y Bv.Artigas"));
			nuevoCentro(new Centro("Blandengues", "Av.Italia y L.A. Herrera"));
			nuevoCentro(new Centro("Prado", "Aigua y Valdense"));
			nuevoCentro(new Centro("Maroñas", "Veracierto y Chayos"));
			nuevoCentro(new Centro("CENTRO VACIO", "Mas abajo que YPF"));
		}

		private void cargaDonaciones()
		{
			DateTime fecha1 = new DateTime(2019, 12, 24);
			DateTime fecha2 = new DateTime(2020, 1, 1);
			DateTime fecha3 = new DateTime(2019, 6, 28);
			DateTime fecha4 = new DateTime(2020, 2, 13);
			DateTime fecha5 = new DateTime(2020, 2, 2);

			DonacionEconomica donEco1 = new DonacionEconomica(15000);
			DonacionEconomica donEco2 = new DonacionEconomica(1000, fecha2, (Voluntario)usuarios[3]);

			DonacionEconomica donEco3 = new DonacionEconomica(0);

			nuevaDonacionEconomica(donEco1, (Voluntario)usuarios[4]);
			nuevaDonacionEconomica(donEco2, (Voluntario)usuarios[4]);
			// La tercera donacion economica falla por tener un monto de 0.
			nuevaDonacionEconomica(donEco3, (Voluntario)usuarios[4]);


			List<ProductoDonado> listaDon1 = new List<ProductoDonado>();
			List<ProductoDonado> listaDon2 = new List<ProductoDonado>();
			List<ProductoDonado> listaDon3 = new List<ProductoDonado>();
			List<ProductoDonado> listaDon4 = new List<ProductoDonado>();
			List<ProductoDonado> listaDon5 = new List<ProductoDonado>();
			List<ProductoDonado> listaDon6 = new List<ProductoDonado>();

			ProductoDonado pd1 = new ProductoDonado(productos[0], 5);
			ProductoDonado pd2 = new ProductoDonado(productos[1], 2);
			ProductoDonado pd3 = new ProductoDonado(productos[3], 3);
			ProductoDonado pd4 = new ProductoDonado(productos[4], 7);
			ProductoDonado pd5 = new ProductoDonado(productos[5], 1);
			ProductoDonado pd6 = new ProductoDonado(productos[6], 4);
			ProductoDonado pd7 = new ProductoDonado(productos[7], 1);
			ProductoDonado pd8 = new ProductoDonado(productos[8], 3);
			ProductoDonado pd9 = new ProductoDonado(productos[9], 6);
			ProductoDonado pd10 = new ProductoDonado(productos[10], 1000);
			ProductoDonado pd11 = new ProductoDonado(productos[11], 9);

         
			listaDon1.Add(pd1);
			listaDon1.Add(pd2);
			listaDon1.Add(pd3);

			listaDon2.Add(pd4);
			listaDon2.Add(pd5);
			listaDon2.Add(pd6);
			listaDon2.Add(pd7);


			listaDon3.Add(pd8);
			listaDon3.Add(pd1);
			listaDon3.Add(pd9);

			listaDon4.Add(pd1);
			listaDon4.Add(pd5);

			listaDon5.Add(pd10);
			listaDon5.Add(pd11);

			nuevaDonacionProducto(listaDon1, usuarios[0], fecha1);
			nuevaDonacionProducto(listaDon2, usuarios[4], fecha2);
			nuevaDonacionProducto(listaDon3, usuarios[4], fecha3);
			nuevaDonacionProducto(listaDon4, usuarios[4], fecha4);
			nuevaDonacionProducto(listaDon5, usuarios[4], fecha5);
			// La sexta donacion falla por tener una lista de productos vacia.
			nuevaDonacionProducto(listaDon6, usuarios[4], fecha5);

		}

		// Recibe una fecha y retorna un string con la cantidad de donaciones recibidas por un centro en esa fecha.
		// Si el centro no ha recibido donaciones da un mensaje acorde.
		public string getStrDonacionByFecha(DateTime desde, DateTime hasta)
		{
            string donaciones = "";

            foreach (Donacion donacion in Donaciones)
			{
                if (donacion.Fecha >= desde && donacion.Fecha <= hasta)
                    donaciones += donacion.ToString();			
			}

			return donaciones;
		}

		// Combina dos funciones (filtrado por Voluntario y filtrado por Fecha) para entregar una lista filtrada tanto por voluntario como por un rango de fechas.
		public List<Donacion> donacionesPorVoluntarioFecha (Voluntario vol, DateTime unaFecha, DateTime otraFecha)
		{
			List<Donacion> listaDon = donacionesPorVoluntario(vol, donacionesPorFecha(unaFecha, otraFecha));
			listaDon.Sort();
			return listaDon;
		}

		public List<Donacion> donacionesPorFecha(DateTime unaFecha, DateTime otraFecha)
		{
			// Ordena las fechas, siendo indiferente ante cual es primero o no.
			List<Donacion> listaDon = new List<Donacion>();
			DateTime inicio = unaFecha;
			DateTime fin = otraFecha;
			if (inicio.Date > fin.Date)
			{
				DateTime holder = fin;
				fin = inicio;
				inicio = holder;
			}
			DateTime inicioMax = DateTime.Today.AddYears(-1);
			if (inicio < inicioMax)
			{
				inicio = inicioMax;
			}

			foreach (Donacion don in donaciones)

			{
				if (don.Fecha >= inicio && don.Fecha <= fin)
				{
					listaDon.Add(don);
				}
			}
			return listaDon;
		}
		public List<Donacion> donacionesPorVoluntario(Voluntario voluntario, List<Donacion> lista) 
		{
			List<Donacion> listaDon = new List<Donacion>();
			foreach (Donacion don in lista)
			{
				if (don.Voluntario.Ci == voluntario.Ci)
				{
					listaDon.Add(don);
				}
			}
			return listaDon;
		}

		public List<Producto> donadosDistintos()
		{
			List<Producto> prodDist = new List<Producto>();
			List<Donacion> donaciones = new List<Donacion>(this.donaciones);
			donaciones.Sort(Donacion.CompararFecha);

			int i = 0;
			while (!(prodDist.Count == 10) && i < donaciones.Count)
			{
				Donacion don = donaciones[i];
				if (don.Tipo == Donacion.TipoDon.producto)
				{
					DonacionProducto dp = (DonacionProducto)don;
					foreach (ProductoDonado pd in dp.Productos)
					{
						if (!prodDist.Contains(pd.Producto))
						{
							prodDist.Add(pd.Producto);
						}
					}
				}
				i++;
			}

			return prodDist;
		}

		public ProductoDonado masDonado()
		{
			ProductoDonado prod = null;
			List<Donacion> donaciones = donacionesPorFecha(DateTime.Today, DateTime.Today.AddYears(-1));
			List<ProductoDonado> contador = new List<ProductoDonado>();
			List<Producto> agregados = new List<Producto>();

			foreach (Donacion don in donaciones) // Por cada Donacion
			{
				if (don.Tipo == Donacion.TipoDon.producto) // de tipo Producto
				{
					DonacionProducto donP = (DonacionProducto)don;
					
					foreach (ProductoDonado p in donP.Productos) // recorre productos donados
					{
						if (!agregados.Contains(p.Producto)) // si no fueron agregados los agrega tal cual.
						{
							agregados.Add(p.Producto);
							contador.Add(p);
						}
						else
						{
							int i = 0;
							bool sumado = false;
							while (i < contador.Count && !sumado) // si ya fueron agregados
							{
								if (contador[i].Producto.Id == p.Producto.Id) // busca el producto y suma al contador
								{
									contador[i].Cantidad += p.Cantidad;
									sumado = true;
								}
								i++;
							}
						}
					}
				}
			}

			if (contador.Count > 0)
			{
				prod = contador[0];
				foreach (ProductoDonado pd in contador)
				{
					if (prod.Cantidad < pd.Cantidad)
					{
						prod = pd;
					}
				}
			}
			else
			{
				return null;
			}
			return prod;
		}

	}
    
}
