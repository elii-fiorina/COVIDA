﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
	class GestorId
	{
		private static int ultimoProd = 0;
		public static int GenProdId
		{
			get { return ++ultimoProd; }
		}
		private static int ultimaDon = 0;
		public static int GenDonId
		{
			get { return ++ultimaDon; }
		}

		private static int ultimoCen = 0;
		public static int GenCenId
		{
			get { return ++ultimoCen; }
		}
	}
}
