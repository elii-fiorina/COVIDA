﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
	public class Voluntario
    {

        #region Atributos
        private int ci;
        private int telefono;
        private DateTime fechaNac;
		private string nombre;
		private string rol;
		private string password;


        #endregion



        #region Propiedades

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }


        public string Rol
        {
            get { return rol; }
            set { rol = value; }
        }


        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public int Telefono
        {
            get { return telefono; }
            set { telefono = value; }
        }

        public int Ci
        {
            get { return ci; }
            set { ci = value; }
        }
       
        public DateTime FechaNac
        {
            get { return fechaNac; }
        }

        #endregion

        #region Metodos
       
        public Voluntario()
        {

        }

        public Voluntario(string nombre, int ci, int telefono, DateTime fechaNac, string pwd)
        {
            this.nombre = nombre;
            this.ci = ci;
            this.telefono = telefono;
            this.fechaNac = fechaNac;
			this.password = pwd;

        }

		public static string validar(Voluntario voluntario)
		{
			string validacion = "#Error/es: ";

			if (voluntario.Nombre.Length < 3)
			{
				validacion += "El nombre debe ser de al menos 3 caracteres |";
			}
			if (voluntario.Ci.ToString().Length != 8)
			{
				validacion += "La CI debe ser de 8 numeros |";
			}
			if (voluntario.Telefono.ToString().Length < 8)
			{
				validacion += "Telefono demasiado corto |";
			}
			if (validacion == "#Error/es: ")
			{
				validacion = "ok";
			}
			return validacion;
		}

		public override string ToString()
		{
            return "Voluntario: " + this.nombre + " | CI: " + this.ci;
		}

		public static Voluntario nuevoAdmin(string nombre, string pwd){
			Voluntario admin = new Voluntario();
			admin.nombre = nombre;
			admin.password = pwd;
			admin.rol = "admin";
			return admin;
		}
		#endregion
	}
}
