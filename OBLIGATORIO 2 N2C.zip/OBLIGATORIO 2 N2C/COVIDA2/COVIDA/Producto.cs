﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Producto
    {

        public enum TipoProd
        {
            bebida = 1,
            alimentoNoPerecedero = 2,
            alimentoFresco = 3,
            productoLimpieza = 4,
            productoHigiene = 5,

        }
        #region Atributos
        private int id = 0;
        private string nombre;
        private int peso;
        private int precio; 
        private TipoProd tipoProd;
        #endregion

        #region Propiedades

        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }
        public int Peso
        {
            get { return peso; }
            set { peso = value; }
		}
		public int Precio
		{
			get { return precio; }
            set { precio = value; }
		}

		public int Id
		{
			get { return id; }
			set { id = value; }
		}

		public TipoProd Tipo
		{
			get { return tipoProd; }
            set { tipoProd = value;  }
		}

		#endregion


		#region Metodos
        public Producto()
        {
           
        }
		public Producto(string nombre, int peso, int precio, TipoProd tipoProd)
        {
            this.nombre = nombre.ToUpper();
            this.peso = peso;
            this.precio = precio;
            this.tipoProd = tipoProd;
        }

		public override string ToString()
		{
			return "Tipo: " + this.tipoProd + " | Producto: " + this.nombre + " | Precio Unitario: " + this.precio;
		}


		public static string validar(string nombre, int precio, int peso){
			string validacion = "#Error/es: ";

			if (nombre.Length < 3)
			{
				validacion += "El nombre debe ser de al menos 3 caracteres |";
			}
			if (precio <= 0)
			{
				validacion += "El precio debe ser mayor a 0 |";
			}
			if (peso <= 0)
			{
				validacion += "El peso debe ser mayor a 0 |";
			}
			if (validacion == "#Error/es: ")
			{
				validacion = "ok";
			}
			return validacion;
		}

        public static bool ValidarTipo(TipoProd tipo)
        {
                      
            return Enum.IsDefined(typeof(TipoProd), tipo);
        }

        #endregion
    }
}
