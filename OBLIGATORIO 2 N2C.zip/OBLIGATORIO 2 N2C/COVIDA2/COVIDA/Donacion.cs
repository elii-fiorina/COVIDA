﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
    public class Donacion : IComparable<Donacion>
    {
       

        public enum TipoDon
        {
			na = 0,
            economica = 1,
            producto = 2

        }
		#region Atributos
		protected int id;
		protected DateTime fecha;
		protected TipoDon tipoDon;
		protected double valor;
		protected Voluntario voluntario;
		protected double vale;
		#endregion

		#region Propiedades
		public int Id
		{
			get { return id; }
			set { id = value; }
		}
		public double Vale
		{
			get { return vale; }
			set { vale = value; }
		}
		public DateTime Fecha
        {
            get { return fecha; }
			set { fecha = value; }
        }
		public double Valor
		{
			set { valor = value; }
			get { return valor; }
		}
		public Voluntario Voluntario
		{
			get { return voluntario; }
			set { voluntario = value; }
		}
		public TipoDon Tipo
		{
			get { return tipoDon; }
		}


		#endregion


		#region Metodos
		public Donacion()
        {
			this.fecha = new DateTime();
			this.valor = 0;
			this.tipoDon = 0;
            
        }
       
        public override string ToString()
        {
            return "Donacion generica";
        }

        public static bool validarDonacion(double monto)
		{
			bool esValida = false;
			if(monto > 0){
				esValida = true;
			}
			return esValida;
		}

		public virtual void calcularVale(){
			float vale = 0;
		}

		public int CompareTo(Donacion other)
		{
			int orden = vale.CompareTo(other.vale) * -1;
			return orden;
		}

		public static Comparison<Donacion> CompararFecha = delegate (Donacion don1, Donacion don2)
		{
			return don1.Fecha.CompareTo(don2.Fecha);
		};
		#endregion
	}
}