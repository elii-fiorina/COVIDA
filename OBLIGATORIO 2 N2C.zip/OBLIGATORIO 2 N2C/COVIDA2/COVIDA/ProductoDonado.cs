﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dominio
{
	public class ProductoDonado
	{
		#region Atributos
		private int id = 0;
		private int cantidad;
        private DateTime fecha;
		private Producto producto;
		#endregion
		#region Propiedades
		public int Id
		{
			get { return id; }
			set { id = value; }
		}
		public Producto Producto
		{
			get { return producto; }
            set { producto = value; }
		}
        public int Cantidad
        {
            get { return cantidad; }
            set { cantidad = value; }
        }
        public DateTime Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }

        

        #endregion
        #region Metodos
        public ProductoDonado()
        {
            id++;
        }

		public ProductoDonado(Producto prod, int cant)
		{
			this.producto = prod;
			this.cantidad = cant;
            
		}

		public static string validar(Producto producto, int cantidad)
        {
			string validacion = "#Error/es: ";
			if (Producto.validar(producto.Nombre, producto.Precio, producto.Peso) != "ok" )
			{
				validacion += "El producto no es valido: |";
				validacion += Producto.validar(producto.Nombre, producto.Precio, producto.Peso);
			}
			if (cantidad <= 0)
			{
				validacion += "La cantidad minima donada es 1 |";
			}
			if (validacion == "#Error/es: ")
			{
				validacion = "ok";
			}
			return validacion;
		}
        public override string ToString()
        {
            return "| Producto: " + Producto.Nombre + " | Precio Unitario: " + Producto.Precio;
        }
        #endregion

    }
}
